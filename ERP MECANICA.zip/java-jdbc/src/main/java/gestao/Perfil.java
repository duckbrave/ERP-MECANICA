package gestao;

public enum Perfil {
	ADMIN,
	PADRÃO

}
