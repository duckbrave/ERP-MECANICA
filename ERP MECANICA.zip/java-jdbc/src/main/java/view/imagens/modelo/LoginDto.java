package view.imagens.modelo;

public class LoginDto {

	private String Usuario;
	private String senha;
	
	
	public String getUsuario() {
		return Usuario;
	}
	public void setUsuario(String usuario) {
		this.Usuario = usuario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	
	
	
	
	
}
